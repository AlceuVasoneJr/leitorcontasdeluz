# Parser específico para Energisa
