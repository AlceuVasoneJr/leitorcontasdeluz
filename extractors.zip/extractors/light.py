# Parser específico para Light
