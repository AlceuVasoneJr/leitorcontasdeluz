# Parser específico para Cemig
