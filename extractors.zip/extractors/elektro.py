# Parser específico para Elektro
